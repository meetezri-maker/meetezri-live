# Billing Service Consolidation — Validated Implementation Plan (v4)

**Status: Planning only.** No application code, schema, migration, import, service, or test file has been changed to produce this revision. No production data was modified. This document is the only artifact written.

**Supersedes:** v3 (2026-07-23, pre-preflight).
**Inputs:** the v3 plan, `BILLING_PHASE1_PREFLIGHT_REPORT.md`, and a further read-only repository and database analysis performed for this revision (which found three writers and one allowance implementation that Phase 1 did not reach — see §2 and §4).

**Confirmed environment context (treated as resolved fact throughout, not as open questions):**
- The connected Supabase project **is the production database**.
- **Stripe test mode is intentional** — the product is in alpha.
- The subscription records belong to **real alpha users**; they are not disposable staging data.
- Stripe moves to **live mode after alpha**.
- Historical duplicates and over-granted credits must therefore be handled **conservatively**.

---

## 0. Executive Summary

v3 was right that the billing surface needs consolidating, and right to gate the schema change behind a read-only preflight. That gate did its job. What it revealed is that **service duplication was the smallest of the problems in this area.**

v3's model was: one canonical service, two functions to migrate, three call sites, and a unique constraint that would almost certainly apply cleanly. Phase 1 falsified the last part and this revision's repository analysis falsified the scale of the first three. The actual situation:

- **13 production writers** touch `subscriptions` or the credit balance, not the 3 v3 enumerated (§2).
- **Five separate implementations** of "grant plan minutes" exist, four of them stacking and one of them *overwriting* — not the three Phase 1 identified (§4).
- The **canonical** `linkSubscriptionToUser()` does not read `session.subscription` at all; it delegates to a customer-wide reconciliation. The behaviour v3 §7 assumed it was preserving does not exist and must be built (§3).
- **12 duplicated `stripe_sub_id` values across 30 rows and 9 real alpha users** block the constraint, and those duplicates **caused confirmed duplicate credit grants** (§7, §8).

v4 therefore addresses eight things, and deliberately keeps them in four separate categories so they can be approved, sequenced, and rolled back independently:

| Category | What it covers | Sections |
|---|---|---|
| **A. Defect prevention** (code, forward-looking) | Unsafe concurrent writers; three-plus allowance implementations; incorrect customer-wide subscription selection during checkout linking; non-atomic row+grant writes | §3, §4, §5, §10 |
| **B. Historical data cleanup** (data, backward-looking) | The 12 duplicated IDs / 30 rows / 18 surplus rows / 9 users, and the credit over-grants they produced | §8 |
| **C. Service consolidation** (the original v3 scope) | Legacy → canonical redirection, thin wrapper, debug script | §1, §2, §11 |
| **D. Adjacent billing integrity** (explicitly *not* absorbed) | Stale `active` rows, admin-created paid rows with no Stripe ID, duplicate trial rows, Stripe↔local drift, webhook never having run | §14 |

**The single most important structural change from v3** is that the unique constraint and the historical cleanup are now designed to land **inside one transaction** (§9). PostgreSQL DDL is transactional, and this table is 296 kB, so `BEGIN; archive; delete surplus; ADD CONSTRAINT; COMMIT;` executes in milliseconds and leaves **no window** in which cleaned data sits unprotected while the still-live defect could re-duplicate it. This removes the need for a maintenance window, a temporary partial index, or a writer freeze, all of which v3's ordering would have required once the data turned out to be dirty.

**What has not changed:** the canonical service choice (§1), the thin-wrapper rollback strategy (§11), the `DbClient`-style transaction-client pattern (§4), and the NULL-semantics reasoning behind the unique constraint (§7). All four were re-verified against the repository for this revision and all four hold.

---

## 1. Canonical Service — Confirmed, With One Correction

**`apps/api/src/modules/billing/services/subscription.service.ts` remains the canonical billing implementation.**

The Phase 1 report surfaced a real problem with this file — its `linkSubscriptionToUser()` is behaviourally *worse* than the legacy one for checkout linking (§3). That is a reason to rebuild one function, not to move the canonical designation. The evidence for the choice, re-verified for v4:

- **It already owns the entire billing route surface.** `billing/index.ts:1-14` re-exports every public billing function from this file, and `billing.controller.ts` imports exclusively from `./index`. Every route in `billing.routes.ts` already runs on it. Moving canonical status to `billing.service.ts` would mean redirecting *all* routes rather than three call sites — strictly more risk.
- **It is the only implementation with correct Stripe-integrated cancellation** (`subscription.service.ts:283-318`, sets `cancel_at_period_end: true` via `stripe.subscriptions.update` at :298). The legacy `cancelSubscription` (`billing.service.ts:403-420`) never contacts Stripe — it flips a local row to `canceled` and returns. It has zero production callers, so this is not a live bug, but it disqualifies the legacy file as a target without a rewrite.
- **Sibling services already depend on it**: `payg.service.ts:6`, `admin-billing-overview.service.ts:1`.
- **It owns the module's caching layer** — `userSubscriptionCache` (:15), `userBillingHistoryCache` (:19), `clearUserBillingCaches` (:23).
- **It is the only file that calls the shared allowance helper** (`subscription.service.ts:494`). Every other grant path uses a private copy (§4).
- Its `getAllSubscriptions` caps page size at `Math.min(limit, 500)` (:352) versus the legacy `Math.min(limit, 100)` (`billing.service.ts:523`) — a deliberate, more capable implementation.

**Why the broken `linkSubscriptionToUser()` does not overturn this:** the defect is confined to one 15-line function that delegates where it should have resolved. Every *other* dimension favours the canonical file, and §3 rebuilds that function properly. Choosing the legacy file instead would trade one broken function for a broken cancellation path, a lower pagination cap, no cache ownership, a private allowance copy, and a full route migration. The correction is to the function, not the designation.

---

## 2. Complete Writer Map

v3 listed three call sites. That was the *import-migration* scope, and as that it was accurate. It was not a map of everything that writes subscription state, and the duplicate incident is a concurrency problem, so the full map is required. **This section is new in v4.** Items marked 🆕 were not identified in the Phase 1 report either.

### 2.1 Writers that create or modify `subscriptions` rows

| # | Writer | Location | Current behaviour | Risk | Target behaviour | Disposition |
|---|---|---|---|---|---|---|
| **W1** 🆕 | Trial creation on signup | `user.service.ts:886-901` | `findFirst({user_id, plan_type:'trial'})` then `create` if absent. No transaction, no constraint. | **Medium.** Racy by the same check-then-write shape. Has already produced **53 surplus trial rows across 31 users** (verified read-only for this revision). Not blocked by the `stripe_sub_id` constraint — these rows are all NULL. | Unchanged in this migration. | **Remains.** Logged in §14 as adjacent work (D3). |
| **W2** | Legacy `linkSubscriptionToUser` | `billing.service.ts:306-350` | Correctly retrieves `session.subscription` and resolves plan from it. Then `findFirst` → early-return-or-`create`, then private allowance grant (:349). Non-atomic. | **High.** Live on the checkout-return path via `user.controller.ts:347`. One of the confirmed duplicate producers. | Deleted; call site redirected to canonical. | **Removed** (thin wrapper, §11). |
| **W3** | Canonical `linkSubscriptionToUser` | `subscription.service.ts:210-225` | Retrieves the Checkout Session, writes `stripe_customer_id`, then delegates wholesale to `syncSubscriptionWithStripe`. **Never reads `session.subscription`.** | **High.** Resolves the plan from a customer-wide list — the behaviour §12's tests forbid. Produces wrong-plan rows when a customer has leftovers. | Rebuilt per §3. | **Rebuilt.** |
| **W4** | Canonical `syncSubscriptionWithStripe` | `subscription.service.ts:393-498` | `stripe.subscriptions.list({customer, status:'all', limit:5})` → first match in `['active','trialing','incomplete','past_due']` → `findFirst` by `stripe_sub_id` → update / update-pending / `create` (:468/:473/:478) → shared allowance grant (:494). Non-atomic. | **High.** The confirmed source of the mixed-plan duplicate groups. | Stays as customer-wide *reconciliation only*; made atomic; no longer reachable from checkout linking. | **Remains, narrowed** (§3, §5). |
| **W4b** | Legacy `syncSubscriptionWithStripe` | `billing.service.ts:716-820` | Same shape as W4 (`create`/`update` at :791/:796/:801) with a private allowance grant at :815. | **High.** Reached from both `/users/me` self-heal paths. | Deleted. | **Removed** (thin wrapper, §11). |
| **W5** | `/users/me` cache-hit self-heal | `user.service.ts:1014-1020` | When cached plan reads `trial` **and** `stripe_customer_id` is set, calls W4b then deletes the profile cache entry. | **High.** Concurrency amplifier — see §10. | Per §10 recommendation. | **Guarded + redirected.** |
| **W6** | `/users/me` cold-load self-heal | `user.service.ts:1111-1120` | Same trigger on the DB-load path; calls W4b then re-reads the subscription. | **High.** Same amplifier. | Per §10 recommendation. | **Guarded + redirected.** |
| **W7** | Webhook `checkout.session.completed` | `billing.webhook.ts:354-437` | `findFirst` by `stripe_sub_id` → update / update-pending / `create` (:391/:403/:416) → private allowance grant (:436). Non-atomic. Guarded per-event by `stripe_webhook_events`. | **High** once webhooks are actually delivered. **Has never run** — the ledger table is empty (§13). | Consolidated onto the shared helper; made atomic. | **Remains, consolidated.** |
| **W8** | Webhook `customer.subscription.updated` | `billing.webhook.ts:440-505` | `findFirst` by `stripe_sub_id` → `update` only. Never creates. No grant. | **Low.** Update-only; cannot duplicate. | Unchanged. | **Remains.** |
| **W9** | Webhook `customer.subscription.deleted` | `billing.webhook.ts:507-521` | `findFirst` → `update` to `status:'canceled'`, **`plan_type:'trial'`**. | **Medium.** Setting `plan_type` to `trial` while `stripe_customer_id` remains set means every canceled subscriber permanently satisfies the W5/W6 self-heal trigger — see §10. | Unchanged in this migration; interaction documented. | **Remains.** |
| **W10** | Webhook `invoice.payment_succeeded` | `billing.webhook.ts:523-580` | Skips `subscription_create`; on `subscription_cycle` updates dates then **inlines** an allowance stack (:563-578). | **Medium.** Renewal grants are idempotent only via the per-event webhook ledger. | Consolidated onto the shared helper. | **Remains, consolidated.** |
| **W11** 🆕 | Admin plan override | `admin.service.ts:1132-1179` | `findFirst` active → `update` else `create` (:1150/:1160), setting `end_date: null` for paid plans; then **overwrites** `profiles.credits`/`credits_seconds` to the plan allowance (:1172-1179). | **Medium.** Creates paid rows with **no `stripe_sub_id`**, and is the only path that *replaces* rather than stacks credits. | Unchanged in this migration. | **Remains.** See §14 (D2). |
| **W12** | `createCheckoutSession` pending row | `subscription.service.ts:143` | Creates the `incomplete` placeholder with NULL `stripe_sub_id` that `pendingCandidate` later claims. | **Low.** NULL id, exempt from the constraint. | Unchanged. | **Remains.** |
| **W13** | `createSubscription` (canonical / legacy) | `subscription.service.ts:88-111`, `billing.service.ts:115-190` | Update-or-create paths for manual/admin creation. | **Low.** Not on the checkout path. | Legacy copy removed with the wrapper. | **Remains / removed.** |

### 2.2 Evidence this map is complete

`grep -rn "subscriptions\.(create|update|upsert|updateMany|createMany|delete|deleteMany)"` across `apps/api/src` returns exactly the locations above plus test doubles in `billing.webhook.test.ts`. No other module writes the table.

### 2.3 What this changes about the v3 scope table

v3 §2's three-row table remains **correct as the import-migration scope** — those are still the only three production imports of `billing.service.ts`, re-verified (`user.controller.ts:4,347`; `user.service.ts:6,1016,1113`). What v4 adds is that fixing those three imports does not by itself fix the concurrency defect, because W1, W7, W10 and W11 are unsafe writers that no import redirection touches.

---

## 3. Rebuilding Checkout-Specific Linking

### 3.1 The problem, precisely

```ts
// subscription.service.ts:210-225 — current canonical implementation
export async function linkSubscriptionToUser(userId: string, sessionId: string) {
  const session = await stripe.checkout.sessions.retrieve(sessionId);
  if (!session.customer) return;
  await prisma.profiles.update({ where: { id: userId }, data: { stripe_customer_id: session.customer } });
  await syncSubscriptionWithStripe(userId);   // ← customer-wide list; ignores session.subscription
  clearUserBillingCaches(userId);
}
```

`session.subscription` is never read. The plan is resolved downstream by `stripe.subscriptions.list({ customer, status: 'all', limit: 5 })` (`:401-405`) taking the first entry matching `['active','trialing','incomplete','past_due']` (`:409-410`). For a customer with a leftover `incomplete` or an earlier subscription, that first match is **not necessarily the one this checkout just created** — which is exactly how duplicate groups 1–3 ended up containing conflicting `core`/`pro` plan types for a single Stripe subscription ID.

### 3.2 Intended responsibility of `linkSubscriptionToUser(userId, checkoutSessionId)`

The public function keeps its signature and becomes a thin entry point over a private helper that performs, in this order:

1. **Retrieve the exact Stripe Checkout Session** by the supplied `checkoutSessionId`.
2. **Validate the session/customer relationship** — the session must carry a `customer`; reject/return `missing_customer` otherwise. Persist `stripe_customer_id` on the profile only after this check.
3. **Read `session.subscription`.** If absent or unresolvable, return `missing_subscription` and write nothing — this is a one-time-payment or incomplete session, not a subscription link.
4. **Retrieve that exact Stripe subscription** by ID, with `expand: ['items.data.price']`. Never `subscriptions.list`.
5. **Determine the purchased plan from that subscription** — `items.data[0].price.id` matched against `STRIPE_PRICE_IDS.core` / `.pro`, falling back to `subscription.metadata.planType`. If neither resolves to a known paid plan, return `plan_unresolved` and write nothing.
6. **Create or reconcile the local subscription row**, inside a transaction (§5).
7. **Grant the allowance exactly once**, in that same transaction, through the single shared helper (§4).
8. **Invalidate caches** — `clearUserBillingCaches(userId)` and `invalidateUserProfileCache(userId)` — **after commit** (§5, §6).
9. **Return a meaningful result classification** (§15).

### 3.3 Structure

```
subscription.service.ts

  export linkSubscriptionToUser(userId, checkoutSessionId)
          ↓
  private linkSubscriptionFromCheckoutSession(userId, checkoutSessionId)
          ↓
  ── outside any transaction ──────────────────────────────
  1. stripe.checkout.sessions.retrieve(checkoutSessionId)
  2. validate session.customer
  3. read session.subscription                    → missing_subscription
  4. stripe.subscriptions.retrieve(thatId, {expand:['items.data.price']})
  5. resolve plan from that subscription's price  → plan_unresolved
  ── prisma.$transaction(async (tx) => { ─────────────────
  6. create-or-reconcile the row, keyed on stripe_sub_id
  7. grant allowance via the shared DbClient-aware helper
  ── }) commit ───────────────────────────────────────────
  8. clearUserBillingCaches + invalidateUserProfileCache   (after commit only)
  9. return { result, ... }
```

`getOrCreateStripeCustomer` in the same file is already a non-exported helper, so the private-helper convention matches the file's existing style.

### 3.4 `syncSubscriptionWithStripe()` stays separate

It remains its own export with its own customer-wide reconciliation logic, used for **recovery and synchronisation only** — never as the implementation of checkout linking. The two functions answer different questions: *"which subscription did this specific checkout create"* (anchored to a session, transaction-scoped) versus *"what is this customer's subscription state right now"* (a broad sweep with no specific anchor). Collapsing them is what produced the current defect. It will still be made atomic per §5, since it also creates rows and grants allowances.

**Regression risk to state plainly:** this is a behaviour change to a live conversion path, not a refactor. Today a user whose checkout session is stale but whose customer has an active subscription still gets linked (via the customer-wide sweep). After this change, that case returns `missing_subscription` from the link path and is instead handled by reconciliation. The §12 baseline tests must capture today's behaviour first so this difference is visible and deliberate rather than discovered in production.

---

## 4. Consolidating the Allowance-Grant Implementations

### 4.1 There are five, not three

Phase 1 found three. This revision's analysis found **five**, and the fifth behaves differently from the other four.

| # | Implementation | Location | Semantics | Callers |
|---|---|---|---|---|
| **A1** | `addSubscriptionAllowanceMinutes` (shared) | `credit-balance.service.ts:35-55` | Stacks: reads `credits`/`credits_seconds`, adds `minutes*60`, writes both. | `subscription.service.ts:494` — **the only one** |
| **A2** | `addSubscriptionAllowance` (private) | `billing.service.ts:26-~46` | Byte-for-byte identical to A1. | `billing.service.ts:349`, `:815` |
| **A3** | `addSubscriptionAllowance` (private) | `billing.webhook.ts:88-109` | Byte-for-byte identical to A1. | `billing.webhook.ts:436` |
| **A4** 🆕 | **Inlined**, no helper at all | `billing.webhook.ts:563-578` | Same stacking logic written inline inside `handleInvoicePaymentSucceeded`. | renewal path (W10) |
| **A5** 🆕 | Direct credit overwrite | `admin.service.ts:1172-1179` | **Replaces** `credits`/`credits_seconds` with the plan allowance — does not stack. | admin plan override (W11) |

Both `billing.service.ts:7` and `billing.webhook.ts:7` **import `addSubscriptionAllowanceMinutes` and then never call it.** The import is dead in both files.

### 4.2 Target signature and client type

**The repository already contains an exported transaction-client type, and it already uses the exact optional-trailing-parameter shape this helper needs.** `gamification/points.service.ts:16`:

```ts
/** Accepts either the base client or an interactive-transaction client. */
export type PrismaClientLike = Prisma.TransactionClient | typeof prisma;
```

used as `client: PrismaClientLike = prisma` at `points.service.ts:64`, `:80`, `:90`. `sessions.service.ts:17` declares an equivalent but **non-exported** `DbClient` with a *required first* parameter. Two declarations of the same type, neither in a shared location.

**Recommendation:** move the type to `apps/api/src/lib/prisma.ts` — which already exports the singleton every module imports — and re-export it from both existing sites so nothing breaks:

```ts
// apps/api/src/lib/prisma.ts (addition)
export type PrismaClientLike = Prisma.TransactionClient | typeof prisma;
```

Billing importing `PrismaClientLike` from `gamification/points.service` would be a bad dependency direction; duplicating it a third time is what got us five allowance implementations. `lib/prisma.ts` is the only location every module already depends on.

**Target signature**, following the `points.service.ts` precedent (optional, trailing, defaulted — so all existing callers are source-compatible):

```ts
export async function addSubscriptionAllowanceMinutes(
  userId: string,
  minutesToAdd: number,
  client: PrismaClientLike = prisma
): Promise<void>
```

The body changes only in that `prisma.profiles.findUnique` / `prisma.profiles.update` become `client.profiles.findUnique` / `client.profiles.update`.

### 4.3 Consolidation actions

| Action | Target | Note |
|---|---|---|
| Extract `PrismaClientLike` to `lib/prisma.ts` | new export | Re-export from `sessions.service.ts` and `points.service.ts` to avoid touching their call sites. |
| Add the `client` parameter to A1 | `credit-balance.service.ts:35` | Default preserves every current caller. |
| Delete A2 | `billing.service.ts:26` | Falls out of the §11 wrapper conversion; both call sites (`:349`, `:815`) disappear with the legacy functions. |
| Delete A3, route `:436` to A1 | `billing.webhook.ts:88` | The dead import at `:7` becomes live. |
| Delete A4, route the renewal grant to A1 | `billing.webhook.ts:563-578` | Behaviour-identical; this is the change most likely to be missed. |
| **Leave A5 alone**, document it | `admin.service.ts:1172` | Overwrite-not-stack is plausibly *intended* for an admin override. Changing it is a product decision, not a consolidation one. Flagged in §14 (D2) and listed as Open Decision 3. |

After this, exactly one stacking implementation exists, it is transaction-capable, and every automated grant path routes through it.

---

## 5. Atomicity

### 5.1 The invariant

Whenever a new subscription entitlement is created, these two writes commit together or not at all:

```
create-or-link the subscriptions row
      +
grant the plan allowance to profiles
```

Implemented as `prisma.$transaction(async (tx) => { ... })` with the row write and `addSubscriptionAllowanceMinutes(userId, minutes, tx)` both inside.

### 5.2 Boundaries

- **Stripe reads happen before the transaction opens.** Holding a database transaction across a network round-trip to Stripe extends lock duration for no correctness benefit. All four Stripe calls in §3.2 steps 1–5 complete first.
- **Cache invalidation happens after commit, never inside.** Invalidating inside the transaction would publish a state that a rollback then un-publishes.
- **Precedent:** `payg.service.ts:174-200` already does exactly this shape in the billing module — `prisma.$transaction(async (tx) => { tx.payment_transactions.create(...); tx.profiles.update(...) })` for credit purchases. `billing.webhook.ts:312` and `billing.service.ts:858` use it too. This is established practice here, not a new pattern.

### 5.3 Defined behaviour for every case

| Case | Behaviour | Classification (§15) |
|---|---|---|
| **Successful first link** | Row created and allowance granted in one commit. Caches invalidated after. | `linked` |
| **Already-linked subscription** | A row matching this `stripe_sub_id` exists. Reconcile mutable fields (status, period dates, amount). **Do not grant again.** | `already_linked` |
| **Concurrent duplicate requests** | The unique constraint (§7) arbitrates. Exactly one transaction commits a new row; the others raise `P2002` and take the recovery path below. Exactly one allowance is granted, by construction. | one `linked`, N−1 `unique_conflict_recovered` |
| **Prisma `P2002` on `stripe_sub_id`** | Catch, re-read the winning row by `stripe_sub_id`, verify it exists and its `user_id` matches, return without creating or granting. Because the winner's write was atomic, the winner's allowance is already committed — this is guaranteed structurally, not by inspection. Follows the established `points.service.ts:52-58` pattern of treating P2002 as an idempotent no-op. | `unique_conflict_recovered` |
| **Transaction rollback** (allowance throws mid-transaction) | Neither write persists. No orphan row, no partial credit. Caches are *not* invalidated. The error propagates to the caller. A subsequent retry performs the full operation cleanly. | `failed` (`db_error`) |
| **Stripe retrieval failure** | No transaction is ever opened. Nothing is written. Error surfaces with a category, not a raw message. | `failed` (`stripe_error`) |
| **Invalid or missing `session.subscription`** | Return before opening a transaction. No row, no grant, no cache invalidation. Mirrors today's early-return in both implementations. | `missing_subscription` |
| **Plan resolution failure** (price matches no known plan and no usable metadata) | Return before opening a transaction. Write nothing — **do not** fall back to `trial`, which would silently downgrade a paying user. | `plan_unresolved` |

### 5.4 What atomicity does not solve

It makes the *forward* path safe. It does not retroactively determine whether a row created before this ships had its allowance completed — there is no column or ledger recording that, and a profile's `credits` balance is not a usable proxy (it is a running total mixed with trial grants, renewals, PAYG purchases, and session deductions). That is the subject of §6, and it is the reason the historical cleanup in §8 does not attempt to recompute anyone's balance.

---

## 6. Idempotency Marker Decision — Reopened

v3 recommended **against** a durable marker, reasoning that no evidence of under-crediting existed. That reasoning is still literally true and is now beside the point: Phase 1 found confirmed **over**-crediting. User `bf112c04` holds `credits = 830` against a correct entitlement of `30 + 400 = 430` — two `pro` grants for one Stripe subscription, matching to the minute with zero consumption. The decision is reopened here with that evidence.

### Option A — No new marker

Rely on the unique `stripe_sub_id` constraint + the atomic transaction + row existence.

| Dimension | Assessment |
|---|---|
| Idempotency strength | **Strong for checkout linking.** The constraint makes two rows for one Stripe subscription impossible, and the transaction binds the grant to row creation, so "one row ⇒ one grant" holds by construction. |
| Migration complexity | **None.** No schema change. |
| Historical repair usefulness | **None.** Cannot determine whether any pre-existing row was granted. |
| Auditability | **Poor.** No record of which grant was made, when, or why. |
| Future renewal support | **Weak.** Renewals (W10) grant repeatedly against the *same* row, so row existence cannot gate them. They are currently protected only by the per-event `stripe_webhook_events` ledger — real, but it guards *event replay*, not *two different events describing the same billing period*. |
| Rollback risk | **Lowest.** Nothing to roll back. |

### Option B — Subscription-level marker (`subscriptions.allowance_granted_at`)

| Dimension | Assessment |
|---|---|
| Idempotency strength | **Marginal over Option A.** For first-link it adds nothing the constraint doesn't already provide. |
| Migration complexity | Low — one nullable column. But **backfill is undecidable**: existing rows cannot be classified as granted or not. |
| Historical repair usefulness | **Low, and misleading.** A column that is NULL for every pre-existing row conveys "unknown", not "not granted" — inviting exactly the wrong repair. |
| Auditability | Weak — one timestamp, no amount, no reason. |
| Future renewal support | **Structurally wrong.** A renewal grants again against the same row, so the column must be overwritten each cycle, destroying the previous value and providing no cross-cycle idempotency. |
| Rollback risk | Low, but the column becomes permanent de-facto API surface. |

### Option C — Dedicated allowance ledger

A table keyed uniquely on `(user_id, stripe_sub_id, grant_reason, period_start)` with the amount granted, inserted inside the same transaction as the grant; a `P2002` on insert means "already granted" and the grant is skipped.

| Dimension | Assessment |
|---|---|
| Idempotency strength | **Strongest, and it is the only option that covers renewals** — each billing period is a distinct key. |
| Migration complexity | Moderate: one new table, one unique index, one insert inside the existing transaction. |
| Historical repair usefulness | **Same as A and B for existing rows** — the ledger starts empty. Its value is forward-looking, plus a clean seam for a *deliberate*, separately-approved backfill later. |
| Auditability | **Strongest.** Every grant carries user, subscription, reason, period, and amount — which is precisely what was missing when Phase 1 had to reconstruct over-granting by arithmetic. |
| Future renewal support | **Full.** |
| Rollback risk | Low — additive; an unused table is inert. |
| Repository precedent | **Already implemented and working here.** `point_transactions` has unique index `point_transactions_user_source_item_key (user_id, source_type, source_item_id)` (verified in production), and `points.service.ts:37-59` inserts, catches `P2002`, and returns `inserted: false` — an idempotent no-op. That is Option C, in this codebase, in production, today. |

### Recommendation

**Adopt Option A for the v4 implementation scope. Mandate Option C before Stripe live mode. Reject Option B outright.**

Reasoning:

- **Option A fully closes the confirmed defect.** Every duplicate in production came from concurrent checkout linking, and the constraint plus the atomic transaction make that specific failure impossible. Shipping a schema change is not required to fix what actually broke.
- **Option B should not be built at all.** It cannot express renewals, and its backfill is undecidable, so it would ship a column that is wrong for the recurring case and uninterpretable for the historical one.
- **Option C is right, but not urgent, and it is not free.** The renewal gap it closes is currently mitigated by the webhook event ledger, and — decisively — **the renewal path has never executed in production** (`stripe_webhook_events` is empty, §13). Building ledger infrastructure for a path with zero production executions, during alpha, ahead of the cleanup that unblocks everything else, is the wrong order. It becomes necessary the moment webhooks are live and money is real, which is exactly the Stripe live-mode boundary.

This keeps v3's principle intact — do not add schema unless the repository proves it is required — while being honest that the repository *has* now proven it will be required, just not yet. **No schema change is proposed in this task.**

---

## 7. Unique Constraint on `subscriptions.stripe_sub_id`

### 7.1 Preflight status: executed, FAILED

Run 2026-07-23 against production. **12 duplicated values, 30 rows, 18 surplus rows, 9 users, 0 cross-user.** Full detail in `BILLING_PHASE1_PREFLIGHT_REPORT.md`.

### 7.2 What survives from v3 §5 unchanged

**PostgreSQL and Prisma both permit multiple NULLs under a unique constraint.** PostgreSQL treats each NULL as distinct for uniqueness purposes (standard SQL null semantics), and Prisma's `@unique` on a nullable scalar maps to that same constraint without altering null handling. The **256 NULL `stripe_sub_id` rows are unaffected** — trial rows (W1), pending checkout placeholders (W12), and admin-created rows (W11) all remain valid. Only two or more rows sharing a *non-null* value violate it. Re-verified for v4; no revision needed.

One v3 statement *was* falsified and is corrected here: v3 said all trial rows carry NULL. Row `cffbd6f0-e668-4bb1-90bd-0b3fc36e028d` is `plan_type = 'trial'` with `stripe_sub_id = sub_1TCOZRBt…`. Harmless — the value is not duplicated — but the claim was wrong.

### 7.3 Constraint mechanics

- Target: `@unique` on `subscriptions.stripe_sub_id`, emitting `CREATE UNIQUE INDEX subscriptions_stripe_sub_id_key ON public.subscriptions (stripe_sub_id)`.
- The table is **296 kB / 401 rows**. A plain (non-`CONCURRENTLY`) index build takes milliseconds. **This matters**: `CREATE INDEX CONCURRENTLY` cannot run inside a transaction, and §9's chosen sequence depends on the constraint being added transactionally. At this table size the concurrent build buys nothing and costs the atomicity guarantee.
- No existing unique index on this column (verified: only `subscriptions_pkey`, plus four non-unique indexes).
- Rollback is `DROP INDEX` / `DROP CONSTRAINT` — non-destructive.

### 7.4 Re-run gate

The preflight query is re-run as the final statement **inside** the cleanup transaction (§9) and must return zero rows before the `ADD CONSTRAINT` in that same transaction. If it returns anything, the transaction rolls back and nothing changed.

---

## 8. Historical Cleanup Workstream

**Separate workstream. Nothing here executes during this planning task, and nothing here executes without its own approval gate (§16, Gate 2 and Gate 4).**

Scope: **12 duplicated `stripe_sub_id` values · 30 rows in duplicate groups · 18 surplus rows · 9 affected users.**

### 8.1 Survivor selection

Deterministic, applied per duplicate group, in this order:

**Rule 1 — Plan correctness from Stripe, where Stripe still has the answer.** For the 5 groups whose subscription still resolves (`sub_1TFWXYBt…`, `sub_1TPN9yBt…`, `sub_1TLqESBt…`, `sub_1TFaVWBt…`, `sub_1TRE54Bt…`), retrieve the live subscription and derive the correct `plan_type` from `items.data[0].price.id`. This is authoritative. Where the surviving row's plan disagrees, correct that field on the survivor.

**Rule 2 — Oldest `created_at` wins.** Among rows in a group, keep the one with the smallest `created_at`. This is the original race winner, and `created_at` is **database-generated** (`timezone('utc', now())`, schema default) and therefore monotonic and trustworthy.

**Rule 3 — `updated_at` is never a tiebreaker.** It is written application-side from `new Date()` (`subscription.service.ts:463`), and **7 production rows have `updated_at` earlier than `created_at`** — 5 of them inside duplicate groups. It is not a reliable ordering signal for exactly the rows being cleaned.

**Rule 4 — Status correctness is applied to the survivor, not used to select it.** Groups 1–3 contain both `active` and `incomplete` rows, and groups 1–3 contain *conflicting plan types* (`core` and `pro`) for one Stripe subscription. Selecting by status would sometimes pick a younger row and contradict Rule 2. Instead: select by Rules 1–2, then correct the survivor's `status` from live Stripe where available, and leave it untouched where Stripe returns 404.

**Rule 5 — Never merge across users.** All 12 groups are single-user, so this rule should never fire. It is asserted as a hard precondition anyway: if any group is found spanning users at execution time, the cleanup aborts entirely rather than proceeding on the remaining groups.

**The 7 groups Stripe no longer has** (`resource_missing`) fall through to Rules 2–4 on local data alone. Their surviving rows keep whatever `plan_type` and `status` the oldest row carries, and are **not** guessed at.

### 8.2 Archival

Surplus rows are **archived, then removed** — never deleted outright. 18 rows against a 296 kB table; the cost is nil and it preserves the ability to answer "what did this alpha user actually have" during a later billing dispute or the live-mode transition.

A dedicated archive table is recommended over the existing generic `audit_logs` (which is `action` + `jsonb details`, 2 rows, and not shaped for full row snapshots). The archive must preserve:

| Field | Purpose |
|---|---|
| Complete original row | Every column of the removed `subscriptions` record, verbatim |
| `cleanup_batch_id` | Groups all rows removed by one execution; makes the whole batch reversible as a unit |
| `reason` | Why this row was removed (e.g. `duplicate_stripe_sub_id`) |
| `survivor_subscription_id` | The row that was kept for this group — the reversal key |
| `archived_at` | Execution timestamp |
| Review metadata | Who approved, which dry-run report this execution corresponds to, and the Stripe state observed for the group at execution time |

Creating this table is a schema change and is therefore **out of scope for this task** — it is proposed here and built only after Gate 2.

### 8.3 Credit over-grants

**Default: forgive and document. Do not reclaim. Do not recompute balances.**

Cleanup **must not touch `profiles.credits` or `credits_seconds` at all.** These are real alpha users. Choosing among the three options:

- *Forgive silently* — leaves no record. When Stripe moves to live mode and real balances start mattering, nobody will be able to reconstruct which balances were inflated or by how much. Rejected.
- *Reclaim only unused excess* — technically feasible (the per-user delta is computable from the duplicate groups), but it degrades the account of an alpha user who did nothing wrong, in exchange for minutes that cost the business nothing in test mode. It also requires deciding what "unused" means against a single blended balance that mixes trial grants, plan grants, PAYG purchases, and session deductions — a determination the current data model cannot support (§5.4). Rejected.
- **Forgive and document — chosen.** The dry-run report records the exact per-user over-grant (computable: `sum(plan credits for each surplus row)`), and that record is retained with the archive batch. Balances are left exactly as they are. If the product owner later decides a correction is warranted — most plausibly at the live-mode transition — the data to execute it precisely will exist. This keeps a data-integrity migration from silently adjusting customer balances, which is the failure mode most likely to generate a support incident.

Any actual balance correction is a **separate, separately-approved policy decision** (Open Decision 1).

### 8.4 Cleanup verification

**Dry-run first, as a distinct approved artifact (Gate 2).** The dry-run is read-only and must emit:

1. Every affected row — all 30, with full column values.
2. Every selected survivor — 12 rows, with the rule that selected each and the Stripe state consulted.
3. Every row that would be archived — 18 rows, with its `survivor_subscription_id`.
4. Per-user credit over-grant amounts — **reported, not applied**.
5. An explicit assertion that no group spans multiple users.
6. Row-count reconciliation: `401 total → 383 expected`, `145 non-null stripe ids → 127 expected`, `127 distinct → 127 unchanged`.

**Post-execution verification**, all inside or immediately after the same transaction:

1. The §7.1 preflight query returns **zero rows**.
2. `COUNT(*) = 383`; `COUNT(stripe_sub_id) = 127`; `COUNT(DISTINCT stripe_sub_id) = 127`.
3. Archive table contains exactly 18 rows for this `cleanup_batch_id`.
4. Every archived row's `survivor_subscription_id` resolves to a row still present in `subscriptions`.
5. No archived row's `user_id` differs from its survivor's `user_id`.
6. `SELECT COUNT(*) FROM profiles WHERE credits IS DISTINCT FROM <pre-cleanup snapshot>` returns **0** — credit balances provably unchanged.
7. The unique constraint exists and is valid.

---

## 9. Sequencing: Cleanup vs. Constraint vs. Defect Prevention

v3 placed the constraint at step 3, before the atomicity work. That was defensible when the data was assumed clean. It is not defensible now: cleaning data while the defect that dirtied it is still live means the cleanup can race it.

### Strategy A — Prevention first, then clean, then constrain

1. Deploy defect prevention (§3, §4, §5) → 2. Clean historical duplicates → 3. Add unique constraint.

| Dimension | Assessment |
|---|---|
| Re-duplication risk during cleanup | **Reduced but not eliminated.** The atomic transaction does not stop two concurrent transactions from each inserting a row for the same `stripe_sub_id` — only the unique index does. Between steps 2 and 3 the data is clean and unprotected. |
| Deployment complexity | Low — one deploy, one data migration, one schema migration. |
| Downtime | None. |
| Rollback | Clean at every step. |
| Compatibility with existing writers | Good — W1, W11, W12 continue to write NULLs, unaffected. |

### Strategy B — Freeze writers, clean, constrain, then deploy

1. Temporarily disable unsafe writers → 2. Clean → 3. Add constraint → 4. Deploy consolidated implementation.

| Dimension | Assessment |
|---|---|
| Re-duplication risk during cleanup | **Eliminated** — nothing is writing. |
| Deployment complexity | **High.** Requires a feature flag or a deploy purely to disable the self-heal paths, then another to re-enable. Two extra deploys for a 30-row cleanup. |
| Downtime | **Partial functional downtime.** Freezing W2/W5/W6 means users completing checkout during the window do not get linked and see a stale plan. On a conversion path, during alpha, that is a worse customer outcome than the problem being fixed. |
| Rollback | More moving parts; the freeze itself needs reverting. |
| Compatibility | Poor — deliberately breaks live behaviour. |

### Chosen sequence — Strategy A, with cleanup and constraint fused into one transaction

**PostgreSQL DDL is transactional.** The gap Strategy A leaves between "clean" and "protected" can be closed to zero by doing both in one transaction:

```
BEGIN;
  -- 1. snapshot affected profile credit balances (for verification assertion 6)
  -- 2. INSERT surplus rows INTO the archive table
  -- 3. DELETE those surplus rows FROM subscriptions
  -- 4. UPDATE survivors' plan_type/status where Stripe was authoritative
  -- 5. re-run the duplicate preflight — must return zero rows, else ROLLBACK
  -- 6. ALTER TABLE subscriptions ADD CONSTRAINT subscriptions_stripe_sub_id_key UNIQUE (stripe_sub_id);
COMMIT;
```

If any assertion fails, the whole thing rolls back and production is untouched. At 401 rows / 296 kB the entire transaction completes in milliseconds, so the `ACCESS EXCLUSIVE` lock taken by `ADD CONSTRAINT` is held briefly enough to be invisible — which is *why* the non-concurrent index build in §7.3 is the correct choice rather than a limitation.

This yields Strategy A's low complexity and zero downtime **with** Strategy B's zero re-duplication risk, and needs no writer freeze, no feature flag, and no maintenance window.

**A temporary partial unique index is not useful here** and should not be built: NULLs are already exempt from a plain unique constraint (§7.2), so a `WHERE stripe_sub_id IS NOT NULL` partial index would be functionally identical to the real thing while adding a second object to remove later.

**Defect prevention still ships first**, before the cleanup transaction, for two reasons: it stops new duplicates accumulating while the cleanup is being reviewed and approved (a period measured in days, not minutes), and it means the cleanup transaction runs against a system that will not immediately re-dirty the table if the constraint were ever dropped.

**Final order:** defect prevention (deployed and verified) → cleanup dry-run (approved) → cleanup + constraint (one transaction) → post-cleanup verification → caller migration → wrapper. Expanded step-by-step in §16.

---

## 10. `/users/me` Self-Healing

### 10.1 Current behaviour and why it is the amplifier

Both paths fire on the same condition — local plan reads `trial` **and** `stripe_customer_id` is set:

- `user.service.ts:1014-1020` (cache-hit): calls `syncSubscriptionWithStripe`, then deletes the profile cache entry.
- `user.service.ts:1111-1120` (cold-load): calls `syncSubscriptionWithStripe`, then re-reads the subscription.

That condition describes exactly the post-checkout redirect. A frontend issuing more than one `/users/me` while the success page mounts fires multiple customer-wide Stripe reconciliations concurrently — while `linkSubscriptionToUser` is running against the same subscription. Three writers, and the March duplicate groups have three rows each, created 0.003–1.25 s apart.

**There is a second problem that compounds it.** `handleSubscriptionDeleted` (`billing.webhook.ts:507-521`) sets `plan_type: 'trial'` on cancellation while leaving `stripe_customer_id` in place. Every canceled subscriber therefore satisfies the self-heal trigger **permanently** — every `/users/me` for such a user makes a customer-wide Stripe API call, forever. Combined with the 4-of-5 duplicated subscriptions that are `canceled` in Stripe but `active` locally, this is a live latency and API-quota cost on an ordinary read endpoint, not merely a concurrency hazard.

### 10.2 Recommendation

**Guard the write, keep the read. Specifically: (a) single-flight the sync per user, (b) make it non-blocking, and (c) add a negative-result cooldown.**

1. **Single-flight per user.** Keep an in-process map of in-flight sync promises keyed by `userId`; concurrent callers await the existing promise rather than starting another. This directly collapses the three-writer race to one, and it is the smallest change that addresses the actual defect. Note honestly: the API runs as a single process per instance, so this is per-instance, not cluster-wide — it is a strong mitigation, not a guarantee. **The unique constraint (§7) is what makes it a guarantee**; single-flighting removes the load and the lock contention.
2. **Do not let a read request block on a Stripe round-trip.** The cache-hit path (`:1014`) currently *awaits* a Stripe reconciliation before returning a cached profile, which is the worst version of this — a cache hit that is slower than a cache miss. It should return the cached value and trigger the sync out-of-band.
3. **Cooldown on no-op results.** Record the last sync attempt per user and skip re-attempting within a short window when the previous attempt changed nothing. This is what stops the canceled-subscriber infinite-resync described above.

**Explicitly recommended against, for now: moving reconciliation to a dedicated endpoint or a background job.** Both are cleaner architecturally, and either would be the right long-term answer — but each is a new surface with its own scheduling, auth, and failure semantics, landing in the middle of a migration whose blast radius is already wider than v3 assumed. §16 keeps the self-heal in place, guarded, and lists the extraction as post-consolidation work (§14, D6).

**On the general principle** — hidden writes inside ordinary read requests are a genuine design smell, and this is a clear instance of one. The justification for keeping it through this migration is narrow and temporary: it is currently the *only* recovery mechanism for a user whose checkout linking failed, because **the webhook has never run** (§13). Removing it before webhooks are verified would remove the safety net before the primary mechanism is proven. Once §13's checklist passes, the self-heal becomes redundant and should be removed rather than merely guarded.

---

## 11. Legacy Service Strategy and Webhook Readiness

### 11.1 Thin compatibility wrapper (carried forward from v3, unchanged)

Convert `billing.service.ts` into a thin, `@deprecated`-marked wrapper: `linkSubscriptionToUser` and `syncSubscriptionWithStripe` re-exported from their canonical homes, every other export re-exported from `./index`. Rollback becomes a two-line import revert rather than a file restoration. Deletion is a candidate at the **next** release, not this one.

This also removes allowance implementation A2 (§4.1) as a side effect.

### 11.2 Debug script

`scripts/debug-billing-subs.ts:2` imports `getAllSubscriptions` from the legacy path. Update to canonical. Behavioural difference to note so it is not mistaken for a regression: legacy caps page size at `Math.min(limit, 100)` (`billing.service.ts:523`), canonical at `Math.min(limit, 500)` (`subscription.service.ts:352`). Harmless for a debug script.

### 11.3 Webhook readiness verification checklist

**`stripe_webhook_events` contains zero rows.** `completeStripeWebhookProcessing` (`billing.webhook.ts:74-82`) *marks* rows `completed` rather than deleting them, so an empty table means **no Stripe webhook has ever been successfully processed against this database.** Every webhook writer (W7–W10) is therefore unexercised code in this environment, and its per-event idempotency guard has zero production evidence behind it.

**Nothing below is to be configured or triggered now.** This is the verification checklist for the step gated at §16 Gate 8.

| # | Check | How | Repository state |
|---|---|---|---|
| 1 | Webhook endpoint is configured in the Stripe test dashboard for this environment | Stripe dashboard → Developers → Webhooks; confirm a destination pointing at this API's `/billing/webhook` | Not verifiable from the repo |
| 2 | Endpoint is reachable from Stripe | Send a test event from the dashboard; expect `200` and a `stripe_webhook_events` row | Route registered: `billing.routes.ts:17-23` |
| 3 | Raw body is preserved for signature verification | `fastify-raw-body` registered `app.ts:144-145` with `field: 'rawBody'`; route opts `config: { rawBody: true }` (`billing.routes.ts:20`) | ✅ Wired correctly |
| 4 | Signature verification works | `stripe.webhooks.constructEvent(rawBody, sig, secret)` at `billing.webhook.ts:134`; returns 400 on failure, 500 when `STRIPE_WEBHOOK_SECRET` is unset (`:114`) | ✅ Implemented; covered by `billing.webhook.test.ts:84,106,126,244` |
| 5 | `STRIPE_WEBHOOK_SECRET` is set in the deployed environment and matches the configured endpoint | Environment check | Present in `apps/api/.env`; deployed value unverified |
| 6 | Events persist | After a test event, `stripe_webhook_events` has a row with `status='completed'` and a `processed_at` | Table exists, **empty** |
| 7 | Idempotency holds | Replay the same event id; expect `{received:true, duplicate:true}` and no second write | Implemented `:34-72`; tested `:149` |
| 8 | Concurrent-delivery claim behaves | Two simultaneous deliveries of one event → one processes, one gets `503` for Stripe to retry | Implemented `:65`; tested `:185` |
| 9 | Stale-claim reclaim works | A `processing` row older than the stale threshold is reclaimable | Implemented `:59-63`; tested `:461` |
| 10 | `checkout.session.completed` creates/links correctly **and grants exactly once** | Complete a test-mode checkout; assert one row, one grant, via the shared helper post-§4 | Implemented `:354-437`; tested `:263,:314` |
| 11 | `customer.subscription.updated` updates without creating | Trigger a plan change in test mode | Implemented `:440-505` |
| 12 | `customer.subscription.deleted` cancels correctly | Cancel in test mode; **also confirm the §10.1 `plan_type:'trial'` interaction** | Implemented `:507-521`; **untested** |
| 13 | `invoice.payment_succeeded` renews without double-granting | Advance a test clock through a cycle; assert one renewal grant | Implemented `:523-580`; tested `:371` |
| 14 | Handler failure returns 500 so Stripe retries | Fault injection | Implemented; tested `:419` |

Items 1, 2, 5, 6 are environment/configuration facts that cannot be settled from the repository and are the substance of the Gate 8 verification.

---

## 12. Testing Plan

Framework is Jest with `prisma` mocked at module level and `$transaction` stubbed as `mockImplementation(async (fn) => fn(mockPrisma))` — the pattern already used in `sessions.service.test.ts:311`, `completion.service.test.ts:47`, `goals.checkin.test.ts:54`, and `billing.webhook.test.ts:60`. New tests follow it.

Current billing coverage is **one file**, `billing.webhook.test.ts` (14 cases). There is no test for `subscription.service.ts`, `billing.service.ts`, or `credit-balance.service.ts`.

### 12.1 Baseline tests — written and run FIRST, against current behaviour

These lock in today's behaviour before anything changes, and two of them are expected to **document defects rather than assert correctness** — labelled as such so they are not mistaken for endorsements.

- Guest checkout → signup linking, current canonical path. **Documents** that the plan is currently resolved from a customer-wide list (the §3 defect).
- Sequential duplicate calls with the same `sessionId` — current `existingByStripeId` behaviour.
- `/users/me` reconciliation on both cache-hit (`:1016`) and cold-load (`:1113`) paths.
- Existing `billing.webhook.test.ts`, unmodified, as a guardrail that nothing reachable from `billing.routes.ts` moves.

### 12.2 Unit tests

| Test | Asserts |
|---|---|
| Exact `session.subscription` selection | With a Checkout Session whose `subscription` is `sub_B`, on a customer that also has `sub_A` (active, different price), the link path retrieves `sub_B` and **never calls `stripe.subscriptions.list`** |
| Plan resolution from the exact subscription | `items.data[0].price.id` → `core`/`pro`; `metadata.planType` fallback exercised |
| Shared allowance helper with the Prisma singleton | `addSubscriptionAllowanceMinutes(u, 200)` with no client argument uses the default and stacks correctly |
| Shared allowance helper with a transaction client | `addSubscriptionAllowanceMinutes(u, 200, tx)` issues its reads and writes through `tx`, not the singleton |
| Missing `session.subscription` | Returns `missing_subscription`; **no** `$transaction` opened, no row, no grant, no cache invalidation |
| Already-linked subscription | Reconciles mutable fields; asserts the allowance helper is **not** called |
| Invalid plan mapping | Unknown price and no usable metadata → `plan_unresolved`; asserts no write and **no silent `trial` fallback** |
| Cache invalidation after commit only | `clearUserBillingCaches` and `invalidateUserProfileCache` are called after a successful commit and **not called** when the transaction throws |

### 12.3 Transaction tests

| Test | Asserts |
|---|---|
| Both writes commit | One `subscriptions` row created **and** one allowance granted, in one `$transaction` callback |
| Allowance failure rolls back row creation | Force the grant to throw mid-transaction → no row persists, no credit change, error propagates |
| Row-creation failure grants nothing | Force the row write to throw → allowance helper never invoked |
| Retry after rollback succeeds exactly once | A clean retry creates the row **and** grants the allowance, once — not twice |

### 12.4 Concurrency tests

```ts
await Promise.all([
  linkSubscriptionToUser(userId, sessionId),
  linkSubscriptionToUser(userId, sessionId),
  linkSubscriptionToUser(userId, sessionId),
]);
```

Expected: exactly **one** `subscriptions` row; exactly **one** allowance grant (asserted as a credit delta equal to one plan's worth, not two or three — the specific check that would have caught the `bf112c04` over-grant); deterministic classifications (one `linked`, two `unique_conflict_recovered`); no unhandled rejection reaches any caller.

**This test requires the unique constraint to be present** to be a genuine test of the database guarantee rather than an artifact of mock timing. It therefore runs against a real test database, not the module-level mock — the one place in this suite where that is non-negotiable.

### 12.5 P2002 tests

Deterministic unit-level simulation: make the row `create` throw `new Prisma.PrismaClientKnownRequestError(..., { code: 'P2002' })`.

- The loser loads the winning row by `stripe_sub_id` and returns it.
- **No second allowance grant** — the helper is asserted not called.
- **No plan overwrite** — the loser does not rewrite the winner's `plan_type` with its own resolution.
- Emits `unique_conflict_recovered`.

### 12.6 Cleanup tests

Run against a seeded fixture reproducing the production shape (a 3-row group, a 2-row group, one group with conflicting plan types, one group absent from Stripe).

- Survivor selection is deterministic and matches §8.1 — including that a row with `updated_at < created_at` does **not** win on that basis.
- Archive rows are created for every removed row, with `survivor_subscription_id` populated.
- **No cross-user merge** — a synthetic cross-user group causes the cleanup to abort, not to proceed.
- **No credit mutation** — profile balances byte-identical before and after.
- Post-cleanup duplicate query returns zero rows.
- Row-count reconciliation matches §8.4.

### 12.7 Webhook tests

Extending `billing.webhook.test.ts`:

- Repeated delivery of the same event id → single processing (exists at `:149`; keep).
- `checkout.session.completed` → one row, one grant, **through the shared helper** (asserts A3 is gone).
- `customer.subscription.updated` → update only, never create.
- `customer.subscription.deleted` → cancels; **new**, currently untested — and asserts the `plan_type: 'trial'` behaviour explicitly so the §10.1 interaction is visible in the suite.
- `invoice.payment_succeeded` on `subscription_cycle` → renewal grant **through the shared helper** (asserts A4 is gone); on `subscription_create` → no grant.

### 12.8 Regression tests

Guest checkout · paid checkout · trial signup (W1) · `/users/me` both paths · all billing endpoints reachable from `billing.routes.ts` · cancellation (canonical Stripe-integrated path) · cache behaviour · `scripts/debug-billing-subs.ts` runs against the canonical import · the thin wrapper's re-exports resolve and every previously-exported symbol is still exported.

---

## 13. What the Empty Webhook Ledger Means for This Plan

Called out separately because it affects how several sections should be read.

`stripe_webhook_events` is empty, and completed events are *marked*, not deleted. Consequences:

1. **The webhook is exonerated as a cause of the historical duplicates** — it has never run. The confirmed racers are W2, W5, and W6.
2. **W7–W10 are unexercised in production.** Their idempotency guard is well-implemented and unit-tested, but has never been exercised against real Stripe delivery, including retries and out-of-order arrival.
3. **The `/users/me` self-heal is currently the only recovery mechanism** for failed checkout linking. That is why §10 guards rather than removes it.
4. **Renewals have never executed.** This is the decisive input to §6's recommendation to defer the allowance ledger: it would be infrastructure for a code path with zero production executions.

---

## 14. Adjacent Billing Integrity Work

Deliberately **not** absorbed into the consolidation migration. Each is its own ticket with its own classification.

| ID | Finding | Evidence | Classification | Reasoning |
|---|---|---|---|---|
| **D1** | **259 of 380 `active` rows have a past `end_date`** (113 trial, 94 pro, 52 core) | Phase 1 Finding 3 | **Required before Stripe live mode** | Nothing expires subscription rows. `status = 'active'` is not currently a trustworthy signal anywhere in the product. Larger by row count than everything else found. It does not block consolidation — the constraint and atomicity work are indifferent to it — but shipping live billing on top of a status field that means nothing is not acceptable. |
| **D2** | **44 active paid rows with no `stripe_sub_id`** | Phase 1 Finding 4; cause identified in v4 | **Follow-up after consolidation** | Phase 1 could not explain these. This revision can: **28 of the 35 `pro` rows have `end_date IS NULL`, and zero of the 136 Stripe-linked active paid rows do.** `admin.service.ts:1156` is the only writer that sets `end_date: null` for a paid plan. These are overwhelmingly **admin plan overrides (W11)**, which is legitimate behaviour, not corruption. The follow-up is to decide whether admin-granted plans should be distinguishable from Stripe-backed ones — a modelling question, not a bug. |
| **D3** | **53 surplus trial rows across 31 users** | New in v4 (§2.1 W1) | **Follow-up after consolidation** | Same check-then-write shape as the duplicate defect, in `user.service.ts:886-901`. Unblocked by this migration (NULL ids are constraint-exempt) and harmless today because trial grants are capped, but it is the same bug and will need the same fix. Larger than the duplicate set it resembles. |
| **D4** | **Stripe↔local status drift** — 4 of 5 resolvable duplicated subs are `canceled` in Stripe, `active` locally | Phase 1 Finding 3 | **Required before Stripe live mode** | Partly a symptom of D1 and of the webhook never running (D5). Once webhooks are verified, `customer.subscription.deleted` (W9) closes most of it going forward; existing drift needs a one-time reconciliation sweep. |
| **D5** | **Webhook has never processed an event** | Phase 1 Finding 8; §13 | **Required before consolidation** | This is the one item promoted into the critical path. It is Gate 8 in §16. Not because consolidation depends on it, but because §10's decision to *keep* the `/users/me` self-heal is explicitly justified by the webhook being unproven — and that decision cannot be revisited until it is proven. |
| **D6** | **Reconciliation hidden inside a read endpoint** | §10 | **Follow-up after consolidation** | Extracting to a dedicated endpoint or background flow is the right long-term shape. Guarded now, extracted once webhooks are verified and the self-heal becomes redundant. |
| **D7** | **One `trial` row carries a `stripe_sub_id`** | Phase 1 Finding 5 | **Informational only** | Single row, value not duplicated, does not block the constraint. Recorded because it falsified a v3 assumption, not because it needs action. |
| **D8** | **7 rows with `updated_at < created_at`** | Phase 1 Finding 6 | **Informational only** | Application-clock vs database-clock skew under a race. Cosmetic. Its one practical consequence — `updated_at` is unusable as a cleanup tiebreaker — is already handled in §8.1 Rule 3. |
| **D9** | **53 users hold more than one subscription row**; worst case 24 rows / 20 simultaneously active | Phase 1 Finding 7 | **Follow-up after consolidation** | No constraint prevents unbounded concurrent `active` rows per user. Overlaps D1 and D3. The worst-case account is almost certainly QA, but "almost certainly" is not a basis for deleting an alpha user's rows, so it is handled as modelling work, not cleanup. |
| **D10** | **Admin override replaces rather than stacks credits** (A5) | New in v4 (§4.1) | **Informational only** — pending Open Decision 3 | Plausibly intended for an admin override. Documented so it is a deliberate choice rather than an inconsistency nobody noticed. |

---

## 15. Observability and Rollout

### 15.1 Instrumented paths

Structured logging is added in the **same step** as the code it instruments, so the §12 suites exercise code that already logs and runtime verification has data from the first execution:

`linkSubscriptionToUser` · `linkSubscriptionFromCheckoutSession` · `syncSubscriptionWithStripe` · webhook subscription writers (W7–W10) · allowance grants (A1) · P2002 recovery · cleanup execution.

### 15.2 Fields

`userId` · `checkoutSessionId` · `stripeCustomerId` · `stripeSubscriptionId` · `localSubscriptionId` · `plan` · `sourceWriter` (which of W1–W13) · `result` · `allowanceMinutes` · `allowanceGranted` (boolean) · `transactionOutcome` (`committed` | `rolled_back` | `not_opened`) · `executionDurationMs` · `errorCategory`.

**Never logged:** email, name, payment details, card metadata, raw Stripe objects, raw error messages, or any customer-sensitive payload. `errorCategory` is a fixed vocabulary (`stripe_error`, `db_error`, `db_conflict`, `validation_error`), not a message.

`sourceWriter` is new in v4 and is the field that makes the writer map (§2) observable rather than theoretical — when something writes a subscription row unexpectedly, this identifies which of the 13 did it.

### 15.3 Result classifications

| Classification | Meaning |
|---|---|
| `linked` | New row created and allowance granted in this call — normal first-time path |
| `already_linked` | Existing row matched by `stripe_sub_id`; fields reconciled, no new grant — normal idempotent retry |
| `unique_conflict_recovered` | Lost the `P2002` race, located the winner, returned cleanly |
| `missing_customer` | Checkout Session carried no `customer` |
| `missing_subscription` | Session had no resolvable `subscription` — not a subscription checkout |
| `plan_unresolved` | Price matched no known plan and metadata gave no usable fallback; nothing written |
| `failed` | Any other failure, with `errorCategory` |

`allowance_repaired` from v3 is **removed**. It existed to describe repairing a row whose grant status was unknown — a determination the data model cannot support (§5.4) and which §6 has now decided not to build. A classification that can never be legitimately emitted is worse than no classification.

### 15.4 Success metrics and rollback triggers

**Healthy after rollout:**
- `linked` + `already_linked` account for essentially all checkout-link outcomes.
- `unique_conflict_recovered` is non-zero only under genuine concurrency and always resolves without error — its presence is *proof the constraint is working*, not a problem.
- Zero `plan_unresolved` on paths where a known price was used.
- Credit delta per successful link equals exactly one plan allowance.
- `transactionOutcome: rolled_back` is rare and always paired with an `errorCategory`.

**Rollback triggers — revert the import redirection immediately if any occurs:**
- Any `linked` classification emitted twice for one `stripeSubscriptionId`.
- Any user's credit delta exceeding one plan allowance for a single checkout.
- `plan_unresolved` on a checkout that previously linked successfully — indicates the §3 plan-resolution change regressed a working case.
- Sustained `failed`/`stripe_error` above pre-migration baseline.
- Any `P2002` that does **not** resolve to a `unique_conflict_recovered`.

Rollback is the two-line import revert (§11.1). **The constraint and the cleanup are not rolled back with it** — they are correct independently of which service implementation is live, and dropping the constraint would reopen the defect.

### 15.5 Retention

Temporary logging stays for **one full release cycle**, reviewed at the same checkpoint as the wrapper. Reduce to error-level only when: the `linked`/`already_linked`/`unique_conflict_recovered` distribution matches expectations, `failed` is at or below baseline, no rollback trigger has fired, and the webhook checklist (§11.3) has passed with real deliveries.

**The wrapper may be removed** when all of the above hold **and** no import of `billing.service.ts` remains in the codebase **and** at least one full release has elapsed. Wrapper removal is a separate release, never bundled with this one.

---

## 16. Risk Assessment

| Dimension | Before remediation | After v4 implementation | Residual |
|---|---|---|---|
| **Historical data** | 🔴 **High** — 12 duplicated ids, 30 rows, 18 surplus, 9 users; constraint cannot be added | 🟢 **Low** — cleaned and archived inside one transaction with the constraint; re-duplication structurally impossible | Archive must be retained; reversal depends on it |
| **Alpha-user impact** | 🟠 **Medium** — 9 real alpha users hold inconsistent rows; test mode limits financial exposure but not experience | 🟢 **Low** — no balances changed, no rows lost (archived), no user-visible change | Users keep over-granted minutes by design (§8.3) |
| **Duplicate credit grants** | 🔴 **High, confirmed** — `bf112c04` holds 830 vs 430 entitled, arithmetically exact | 🟢 **Low** — constraint + atomic transaction make double-granting impossible on the checkout path | Renewal path (W10) still relies on the per-event ledger — the §6 Option C gap, deferred to live mode |
| **Cleanup execution** | 🟠 **Medium** — cleaning while the defect is live risks racing it | 🟢 **Low** — prevention ships first; cleanup and constraint share one transaction; any failed assertion rolls back everything | Dry-run must be approved and re-verified immediately before execution |
| **Concurrency** | 🔴 **High** — 13 writers, no constraint, no transactions, check-then-write throughout | 🟢 **Low** on the checkout path | W1 (trial, D3) and W11 (admin) keep the unsafe shape; both are constraint-exempt NULL writers |
| **Webhook** | 🟠 **Medium-High** — never executed; four unexercised writers on the money path | 🟡 **Medium** — consolidated onto the shared helper and made atomic, but verification is environmental | Cannot fall below Medium until Gate 8 passes with real deliveries |
| **Migration (code)** | 🟡 **Medium** — larger than v3 assumed: one function rebuilt, four allowance implementations removed, a type extracted | 🟢 **Low-Medium** | The §3 rebuild is a genuine behaviour change on a conversion path — the §12.1 baseline tests exist to make that visible |
| **Rollback** | 🟢 **Low** | 🟢 **Low** — two-line import revert; constraint and cleanup deliberately not reverted with it | Once the constraint is live, reverting to legacy code that lacks P2002 handling would surface raw errors — so revert the *imports*, not the constraint |
| **Stripe live-mode readiness** | 🔴 **High** — D1 (259 stale rows), D4 (drift), D5 (webhook unproven), no renewal idempotency | 🟠 **Medium** — checkout path sound, webhook verified, but D1/D4 remain and Option C is deferred | **This migration does not make the system live-mode ready.** D1, D4, and §6 Option C are prerequisites and are tracked separately |

**Overall: 🔴 High before remediation → 🟢 Low-Medium after**, with the honest qualifier that "after" covers the checkout-linking path thoroughly and the renewal/live-mode path only partially, by deliberate scoping.

---

## 17. Final Implementation Sequence

Twelve steps, twelve gates. Every step states its files/objects, whether it can write, how to roll it back, and what evidence is required before proceeding.

| # | Step | Files / DB objects | Mode | Rollback | Evidence required to proceed |
|---|---|---|---|---|---|
| **1** | **Gate 1 — v4 plan approval** | This document | Read-only | n/a | Explicit approval of §6 (Option A now / C before live), §8.3 (forgive and document), §9 (fused transaction), §10 (guard, don't remove) |
| **2** | Baseline tests against current behaviour | new `subscription.service.test.ts`, `credit-balance.service.test.ts`; existing `billing.webhook.test.ts` untouched | Write (tests only) | Delete test files | All baseline tests green; the two defect-documenting tests explicitly labelled |
| **3** | Extract `PrismaClientLike` to `lib/prisma.ts`; re-export from `sessions.service.ts`, `points.service.ts` | `lib/prisma.ts`, `sessions/sessions.service.ts:17`, `gamification/points.service.ts:16` | Write (code) | Revert commit | Full type-check and existing suites green; zero call-site changes required |
| **4** | Add `client: PrismaClientLike = prisma` to `addSubscriptionAllowanceMinutes`; delete A2/A3/A4 and route their call sites to it | `billing/credit-balance.service.ts:35`, `billing.webhook.ts:88,436,563-578`, `billing.service.ts:26,349,815` | Write (code) | Revert commit | §12.2 helper tests green (singleton **and** transaction client); `billing.webhook.test.ts` green; grep confirms exactly one stacking implementation remains |
| **5** | Build `linkSubscriptionFromCheckoutSession()` + atomic transaction + structured logging, together | `billing/services/subscription.service.ts` | Write (code) | Revert commit | §12.2/12.3/12.5 green; §12.4 concurrency test written but expected to fail until step 8 — recorded as expected |
| **6** | Make `syncSubscriptionWithStripe` atomic; add single-flight + cooldown + non-blocking to both `/users/me` paths | `subscription.service.ts:393-498`, `users/user.service.ts:1014-1020,1111-1120` | Write (code) | Revert commit | Both self-heal baseline tests still green; single-flight collapses concurrent calls to one Stripe round-trip |
| **7** | **Deploy defect prevention.** Imports **not** yet redirected | Steps 3–6 | Write (deploy) | Redeploy previous build | Monitored 24h: no rollback trigger (§15.4); `stripe_webhook_events` and duplicate counts unchanged |
| **8** | **Gate 2 — cleanup dry-run approval.** Produce and review the §8.4 dry-run | Read-only script; `subscriptions`, `profiles`, Stripe GETs | **Read-only** | n/a | All six dry-run outputs produced; survivor list approved row by row; per-user over-grant amounts acknowledged under §8.3 |
| **9** | **Gate 3 — cleanup + constraint, one transaction.** Archive table created first, then the §9 transaction | new archive table; `subscriptions` (18 deletes, ≤12 updates); `subscriptions_stripe_sub_id_key` | **Write** | `ROLLBACK` on any failed assertion; post-commit, restore from archive by `cleanup_batch_id` and `DROP` the constraint | Dry-run re-run immediately beforehand and byte-identical to the approved one; all seven §8.4 post-checks pass inside the transaction |
| **10** | **Gate 4 — post-cleanup verification** | `subscriptions`, archive table, `profiles` | **Read-only** | n/a | Preflight returns 0 rows; counts reconcile to 383/127/127; archive holds exactly 18; **credit balances provably unchanged**; §12.4 concurrency test now passes against the real constraint |
| **11** | Redirect the three call sites; update the debug script; convert `billing.service.ts` to the thin wrapper | `users/user.controller.ts:4,347`, `users/user.service.ts:6,1016,1113`, `scripts/debug-billing-subs.ts:2`, `billing/billing.service.ts` | Write (code) | **Two-line import revert** — constraint and cleanup deliberately *not* reverted | Full regression suite (§12.8) green including unmodified `billing.webhook.test.ts` |
| **12** | **Gate 5 — full regression + deploy + monitored alpha verification** | All of the above | Write (deploy) | Import revert per step 11 | Suite green; then in test-mode Stripe: single guest checkout → one `linked`; rapid retried checkout → `already_linked`/`unique_conflict_recovered`, never `linked` twice; canceled-subscriber `/users/me` no longer re-syncs on every call |
| **13** | **Gate 6 — webhook readiness verification** (§11.3) | Stripe test dashboard; `stripe_webhook_events` | Verify only | n/a | All 14 checklist items pass; `stripe_webhook_events` contains real completed rows for the first time |
| **14** | **Gate 7 — one-release checkpoint.** Reduce logging; remove the wrapper in a **later** release | `billing.service.ts`, logging call sites | Write (code) | Revert commit | §15.5 conditions met; zero imports of `billing.service.ts` remain |

**Approval gates, consolidated:** (1) v4 plan · (2) cleanup dry-run · (3) cleanup execution · (4) post-cleanup verification · (5) full regression + deployment · (6) webhook verification · (7) wrapper removal.

**Steps 1 and 8 and 10 are read-only.** Steps 2–7 write code only. **Step 9 is the only step that writes production data,** and it is the only one behind two consecutive approval gates.

---

## Changelog — v3 → v4

### What changed, and which Phase 1 finding caused it

| # | Change | Caused by |
|---|---|---|
| 1 | Executive summary rewritten to separate four categories: defect prevention, historical cleanup, service consolidation, adjacent integrity work (§0) | Preflight FAIL — the problem is broader than service duplication |
| 2 | **New §2: complete 13-writer map.** v3 listed 3 call sites (correct as import scope, insufficient as a concurrency map). Adds W1 (trial signup) and W11 (admin override), which **neither v3 nor Phase 1 identified** | Root-cause analysis; new v4 repository analysis |
| 3 | **§3 rewritten from "preserve" to "rebuild".** v3 §7 described a checkout/reconciliation separation as existing; it does not | Phase 1 Blocker 2 |
| 4 | **§4 expanded from three allowance implementations to five.** Phase 1 found A1–A3; v4 adds **A4** (inlined at `billing.webhook.ts:563-578`) and **A5** (admin overwrite at `admin.service.ts:1172`) | Phase 1 Blocker 1, extended by v4 analysis |
| 5 | **Client type resolved from repository evidence, not left open.** v3 Open Decision 3 asked whether to duplicate `DbClient`. Answer: `PrismaClientLike` already exists and is exported (`points.service.ts:16`) with the exact optional-defaulted shape needed; extract to `lib/prisma.ts` | v4 analysis — resolves a v3 open decision |
| 6 | **§5 defines all eight outcome cases explicitly**, including two v3 lacked: `missing_customer` and `plan_unresolved` (with an explicit prohibition on falling back to `trial`) | Required by the §3 rebuild |
| 7 | **§6 marker decision reopened and re-answered.** v3 said "no marker, no evidence of under-crediting". v4: evidence is of **over**-crediting; Option B rejected as structurally unable to express renewals; Option C recommended but deferred to live mode; Option A adopted now | Phase 1 Finding 2 |
| 8 | **§8: full historical cleanup workstream** — survivor rules, archival schema, credit policy, dry-run and post-checks. v3 deferred this entirely to an unwritten document | Preflight FAIL |
| 9 | **§9: sequencing inverted and then fused.** v3 put the constraint at step 3, ahead of atomicity. v4 ships prevention first and executes cleanup + constraint in **one transaction**, eliminating the unprotected window without a writer freeze | Phase 1 Recommended Cleanup Strategy step 2 |
| 10 | **§10: `/users/me` self-heal analysed and guarded** (single-flight, non-blocking, cooldown), plus the newly identified permanent-resync loop for canceled subscribers | Phase 1 Root Cause; v4 analysis of W9 |
| 11 | **§11.3: 14-item webhook readiness checklist** | Phase 1 Finding 8 |
| 12 | **§12: testing expanded** to unit / transaction / concurrency / P2002 / cleanup / webhook / regression, on the repo's established Jest+`$transaction` mock pattern. Baseline tests now explicitly include two that **document defects** | Blockers 1 and 2 |
| 13 | **§14: new "Adjacent Billing Integrity Work"** — 10 items classified. **D2's cause identified**: the 44 rows are admin overrides (28/35 `pro` have `end_date IS NULL`; 0/136 Stripe-linked do) | Phase 1 Findings 3–7; v4 analysis resolves Finding 4 |
| 14 | **§15: `allowance_repaired` classification removed**; `sourceWriter`, `transactionOutcome`, `stripeCustomerId`, `localSubscriptionId` added; rollback triggers defined | §6 decision makes `allowance_repaired` unemittable |
| 15 | **§16: risk table restructured** to before / after / residual, with live-mode readiness called out as **not** achieved by this migration | Required by the preflight outcome |
| 16 | **§17: 14 steps, 7 approval gates**, each with mode, rollback, and required evidence | Required by the cleanup workstream |

### v3 assumptions that remain valid

1. **`subscription.service.ts` is the correct canonical service** — re-verified on five independent grounds (§1).
2. **The import-migration scope is exactly three call sites** — re-verified at `user.controller.ts:4,347` and `user.service.ts:6,1016,1113`.
3. **The thin-wrapper rollback strategy** — unchanged (§11.1).
4. **NULL semantics under a unique constraint** — re-verified; the 256 NULL rows are unaffected (§7.2).
5. **`addSubscriptionAllowanceMinutes` cannot join a transaction as written** — confirmed (`credit-balance.service.ts:35`, singleton at `:2`).
6. **The transaction-client pattern is the right fix** — confirmed, with a *better* in-repo precedent than the one v3 cited (`points.service.ts` over `sessions.service.ts`).
7. **Stripe reads belong outside the transaction** — unchanged (§5.2).
8. **The debug script pagination difference (100 vs 500)** — re-verified at `billing.service.ts:523` and `subscription.service.ts:352`.
9. **Billing should call `invalidateUserProfileCache` directly** — confirmed; `subscription.service.ts` currently never calls it.

### v3 assumptions rejected

| Rejected assumption | Why |
|---|---|
| "The preflight will most likely come back clean" | 12 duplicated values, 30 rows, 9 users |
| "§7's checkout/reconciliation separation is carried forward, unchanged — approved" | The separation does not exist; canonical `linkSubscriptionToUser` delegates to a customer-wide list |
| "Extending `addSubscriptionAllowanceMinutes` makes allowance-granting atomic" | It would have made **one of five** implementations atomic |
| "No evidence of existing under-credited rows ⇒ no marker needed" | True but irrelevant; the evidence is of **over**-crediting |
| "Two functions, three call sites" as the concurrency scope | 13 writers touch subscription state |
| "The constraint can be added before the atomicity work" | Only safe against clean data |
| "Whether to duplicate `DbClient` is an open decision" | Resolved from repository evidence — `PrismaClientLike` exists |
| "All `trial`/`incomplete` rows have NULL `stripe_sub_id`" | One trial row carries `sub_1TCOZRBt…` |
| "The webhook is a live writer to design around" | It has never executed in this environment |

---

## Open Decisions

Only decisions that genuinely require product-owner or engineering-lead judgement. Everything resolvable from the repository has been resolved above.

**1. Credit over-grant policy — product owner.**
v4 recommends **forgive and document**: leave all balances untouched, record exact per-user over-grants with the archive batch. The alternative (reclaim unused excess) is technically possible but degrades alpha-user accounts for minutes that cost nothing in test mode. *A decision is required because §8.3 explicitly forbids the cleanup from touching balances — if reclamation is wanted, it must be scoped as separate work.*

**2. Timing of the allowance ledger (§6 Option C) — engineering lead.**
v4 recommends deferring to before Stripe live mode, on the grounds that the renewal path has never executed. *A decision is required because if live mode is closer than the next release, Option C should be pulled into this migration rather than following it.*

**3. Admin override credit semantics (§4.1 A5, §14 D10) — product owner.**
`admin.service.ts:1172-1179` **replaces** a user's credits rather than stacking. v4 leaves it alone and documents it. *A decision is required only to confirm this is intended; if it should stack, it becomes a sixth call site for the shared helper.*

**4. Whether the trial-row duplication (D3) joins this migration — engineering lead.**
53 surplus trial rows across 31 users, same defect shape, different table region. v4 classifies it as follow-up because it is constraint-exempt and harmless today. *A decision is required because fixing it alongside W1 while that code is open is cheaper than a separate pass later.*

---

## Implementation Readiness Verdict

### ✅ Ready for cleanup dry-run planning.

Not ready for implementation, and not blocked either. The preflight closed the v3 gate correctly, and v4 has re-scoped around what it found: the writer map is complete, the allowance implementations are enumerated, the checkout-linking rebuild is specified, the sequencing race is designed out, and the cleanup has deterministic rules with a conservative credit policy appropriate to real alpha users.

**Next authorized action: Gate 1 — approval of this v4 plan**, specifically the four decisions in §6 (Option A now, Option C before live mode), §8.3 (forgive and document), §9 (fused cleanup-and-constraint transaction), and §10 (guard the self-heal rather than remove it).

On approval, the next authorized work is **step 2 — baseline tests**, which is code-only and touches no production data. The first production write is **step 9**, behind Gates 2 and 3.

---

## Stop Condition

This planning task ends here. Not done and not to be done without explicit approval: modifying production data, executing cleanup, creating migrations, changing schema, editing implementation files, updating tests, redirecting imports, configuring Stripe, or beginning any Phase 2 work.

**Confirmation: no application code, schema, migration, import, service, or test file was modified to produce this revision, and no production or Stripe data was written.** The read-only queries run for this revision executed inside `BEGIN TRANSACTION READ ONLY`. This document is the only artifact changed.
